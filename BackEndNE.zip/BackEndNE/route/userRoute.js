const express = require('express');
const router = express.Router();
const {register} = require('../controller/UserController')

router.post('/register',register)
/*router.put('/update',update)
router.delete('/delete',deletCustomer)*/

module.exports = router;